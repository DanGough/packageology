$myWindowsID=[System.Security.Principal.WindowsIdentity]::GetCurrent()
$myWindowsPrincipal=new-object System.Security.Principal.WindowsPrincipal($myWindowsID) 
$adminRole=[System.Security.Principal.WindowsBuiltInRole]::Administrator 
if ($myWindowsPrincipal.IsInRole($adminRole) -eq $false)
{
   $newProcess = new-object System.Diagnostics.ProcessStartInfo "PowerShell";
   $newProcess.Arguments = $myInvocation.MyCommand.Definition;
   $newProcess.Verb = "runas";
   [System.Diagnostics.Process]::Start($newProcess);
   exit
}

Get-AppvClientPackage | Where Path -Match ([regex]::escape((Split-Path -parent $PSCommandPath))) | Stop-AppvClientPackage -Global | Repair-AppvClientPackage -UserState -Global | Unpublish-AppvClientPackage -Global | Remove-AppvClientPackage