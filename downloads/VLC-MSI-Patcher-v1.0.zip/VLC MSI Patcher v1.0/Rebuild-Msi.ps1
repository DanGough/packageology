# Rebuild-Msi.ps1
# Version 1.0
# 24/01/2019
# Dan Gough

# This script was created to rebuild the official VLC MSI packages that corrupt when modified/transformed due them being compiled under WINE instead of Windows.
# It takes MSI packages from the Input subfolder, exports the tables to a fresh database, repacks the files and moves the new MSI to the Output folder.
# Unlikely to work with MSIs containing multiple media entries as WiMakCab.vbs is not designed to cope with these.

# TODO: Ditch WiMakCab.vbs and use DTF instead, ideally exporting/importing cabs instead of rebuilding them.

Add-Type -Path "$PSScriptRoot\WixToolset.Dtf.WindowsInstaller.dll"

function Open-MsiDatabase
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true, HelpMessage = 'Path to MSI package')]
        [System.String] $DatabasePath,
        [Parameter(Position = 1)]
        [WixToolset.Dtf.WindowsInstaller.DatabaseOpenMode] $TransactMode = 'ReadOnly'
    )

    $Database = New-Object -TypeName WixToolset.Dtf.WindowsInstaller.Database -ArgumentList $DatabasePath,$TransactMode
    Write-Output -InputObject $Database
}

function Close-MsiDatabase
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true, HelpMessage = 'MSI Database object')]
        [WixToolset.Dtf.WindowsInstaller.Database] $Database
    )

    $Database.Dispose()
}

function Export-MsiDatabase
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        [WixToolset.Dtf.WindowsInstaller.Database] $Database,
        [Parameter(Mandatory = $false)]
        [string] $Table,
        [Parameter(Mandatory = $false)]
        [string] $Path,
        [switch] $All
    )

    If ($All)
    {
        $Database.ExportAll($Path)
    }
    Else
    {
        $Database.Export($Table,$Path)
    }
    
}

function Import-MsiDatabase
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true, Position = 0)]
        [WixToolset.Dtf.WindowsInstaller.Database] $Database,
        [Parameter(Mandatory = $true, Position = 1)]
        [string] $Path
    )

    If (Test-Path -Path $Path -PathType Container)
    {
        $Database.ImportAll($Path)
    }
    ElseIf (Test-Path -Path $Path -PathType Leaf)
    {
        $Database.Import($Path)
    }
    
}

function Invoke-MsiDatabaseQuery
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, Position = 0)]
        [WixToolset.Dtf.WindowsInstaller.Database]
        $Database,
        
        [Parameter(Mandatory = $true, Position = 1)]
        [System.String]
        $Query,

        [Parameter (Mandatory = $false, Position = 2)]
        [System.Int32]
        $ReturnColumn = 0
    )

    $View = $Database.OpenView($Query)
    $View.Execute()
    $Columns = $View.Columns
    $Record = $View.Fetch()

    While ($Record -ne $null) 
    {
        If ($ReturnColumn)
        {
            Write-Output -InputObject $Record.GetString($ReturnColumn)
            $Record = $View.Fetch()
        }
        Else
        {
            $Fields = New-Object -TypeName System.Collections.Specialized.OrderedDictionary
            $index = 1
            ForEach ($Column in $Columns)
            {
                $Fields.Add($Column,$Record.GetString($index++))
            }
    
            $RowData = New-Object -TypeName PSObject -Property $Fields
            Write-Output -InputObject $RowData

            $Record = $View.Fetch()
        }
    }
    
    $View.Close()
}

$SourceMsiPaths = Get-ChildItem -Path "$PSScriptRoot\Input" -Filter '*.msi' -Recurse -Force | Select-Object -ExpandProperty FullName
$WorkingDir = "$env:Temp\MSI_Rebuilder"

ForEach ($SourceMsiPath in $SourceMsiPaths)
{    
    Write-Host "Rebuilding $SourceMsiPath"
    Write-Host "Creating temp folder $WorkingDir..."
    Remove-Item -Path $WorkingDir -Recurse -Force -ErrorAction SilentlyContinue
    New-Item -Path $WorkingDir -ItemType Directory -ErrorAction SilentlyContinue | Out-Null
    $MsiName = Split-Path -Path $SourceMsiPath -Leaf
    $TempMsiPath = "$WorkingDir\$MsiName".Replace('.msi','_Fixed.msi')

    Write-Host "Extracting files..."
    Start-Process 'msiexec.exe' -ArgumentList "/a `"$SourceMsiPath`" /qn TARGETDIR=`"$WorkingDir`"" -Wait

    Write-Host "Exporting database tables..."
    $SourceMsiDatabase = Open-MsiDatabase $SourceMsiPath
    Export-MsiDatabase -Database $SourceMsiDatabase -Path "$WorkingDir\ExportedTables" -All -ErrorAction SilentlyContinue
    $CabName = (Invoke-MsiDatabaseQuery $SourceMsiDatabase 'SELECT Cabinet FROM Media' | Select-Object -First 1 -ExpandProperty Cabinet).ToLower().Replace('#','').Replace('.cab','')
    Close-MsiDatabase $SourceMsiDatabase

    Write-Host "Creating new MSI..."
    $NewMsiDatabase = Open-MsiDatabase $TempMsiPath -TransactMode CreateDirect
    Get-ChildItem -Path "$WorkingDir\ExportedTables" -Filter '*.idt' | ForEach-Object {Import-MsiDatabase -Database $NewMsiDatabase -Path $_.FullName}
    $NewMsiDatabase.SummaryInfo.WordCount = 0
    Close-MsiDatabase $NewMsiDatabase

    Write-Host "Repacking cab file..."
    Start-Process 'cscript.exe' -ArgumentList "/nologo `"$PSSCriptRoot\WiMakCab.vbs`" `"$TempMsiPath`" $CabName /L /U /C /E" -NoNewWindow -Wait -WorkingDirectory $WorkingDir
    New-Item -Path "$PSScriptRoot\Output" -ItemType Directory -ErrorAction SilentlyContinue | Out-Null
    Move-Item -Path $TempMsiPath -Destination "$PSScriptRoot\Output" -Force
}