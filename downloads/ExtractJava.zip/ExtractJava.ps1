﻿# Original script by Remko Weijnen
# http://www.cupfighter.net/index.php/2014/01/100-automation-of-java-updates/

# Modified by Dan Gough
# http://packageology.com/2014/02/sequencing-java-the-definitive-guide-part-1/

$definition = @"
using System;
using System.Runtime.InteropServices;

namespace Java
{
    public class Installer
    {
        public static int JavaCabId = 0x66;
        public static int JavaMsiStaticId = 0x67;
        public static int JavaMsiId = 0x65; 

        // Java stores the resources in a named resource type JAVA_INSTALLER
        private static string JavaInstaller = "JAVA_INSTALLER";

        public static bool ExtractFile(string dllName, int id, string fileName)
        {
            IntPtr hModule;
            IntPtr lpJavaInstaller;
            IntPtr hResource;
            IntPtr hGlobal;
            IntPtr Buffer;
            uint dwSize;

            // Load file as dll but only for resource loading
            hModule = LoadLibraryEx(dllName, IntPtr.Zero, LOAD_LIBRARY_AS_DATAFILE);
            if (hModule == IntPtr.Zero)
            {
                return false;
            }

            try
            {
                // Get pointer to resource type string
                lpJavaInstaller = (IntPtr)Marshal.StringToHGlobalAnsi(JavaInstaller);

                // Find the resource location
                hResource = FindResource(hModule, (IntPtr)id, lpJavaInstaller);

                // We can release the pointer to the resource type string now
                Marshal.FreeHGlobal(lpJavaInstaller);

                if (hResource == IntPtr.Zero)
                {
                    return false;
                }

                // Get resource size
                dwSize = SizeofResource(hModule, hResource);
                if (dwSize > 0)
                {

                    // Get a handle to the first byte of the resource
                    hGlobal = LoadResource(hModule, hResource);
                    if (hGlobal == IntPtr.Zero)
                    {
                        return false;
                    }

                    // Get a pointer to the resource
                    Buffer = LockResource(hGlobal);
                    if (Buffer == IntPtr.Zero)
                    {
                        return false;
                    }

                    // Copy the resource to a byte array
                    byte[] b = new byte[dwSize];
                    Marshal.Copy(Buffer, b, 0, b.Length);

                    // Save the byte array to disk
                    System.IO.File.WriteAllBytes(fileName, b);

                }
            }
            finally
            {
                // Unload
                FreeLibrary(hModule);
            }

            return true;
        }

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, EntryPoint = "LoadLibrary", SetLastError = true)]
        private static extern IntPtr LoadLibrary([MarshalAs(UnmanagedType.LPTStr)]string lpFileName);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool FreeLibrary(IntPtr hModule);

        private static uint LOAD_LIBRARY_AS_DATAFILE = 0x00000002;
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr LoadLibraryEx([MarshalAs(UnmanagedType.LPTStr)]string lpFileName, IntPtr hReservedNull, UInt32 dwFlags);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr FindResource(IntPtr hModule, IntPtr lpName, IntPtr lpType);

		[DllImport("kernel32.dll", SetLastError = true)]
        private static extern uint SizeofResource(IntPtr hModule, IntPtr hResource);

	    [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr LoadResource(IntPtr hModule, IntPtr hResource);

    	[DllImport("Kernel32.dll", EntryPoint = "LockResource")]
        private static extern IntPtr LockResource(IntPtr hGlobal);
	}
}
"@

Add-Type -TypeDefinition $definition 
$InputFile = $args[0]

If (Test-Path -LiteralPath $InputFile)
{
    $OutputPath = $InputFile + " - Extracted"
    $PackageName = (Split-Path -leaf $InputFile) -replace ".exe",".msi"
    New-Item -ItemType directory -Path $OutputPath -Force | Out-Null
    [Java.Installer]::ExtractFile($InputFile, [Java.Installer]::JavaCabId, $OutputPath + "\data1.cab")
    [Java.Installer]::ExtractFile($InputFile, [Java.Installer]::JavaMsiStaticId, $OutputPath + "\" + $PackageName)
}